from config import DEPTS, YEARS, SEMS

# LMS main data dictionary
lms = {
    "ADMINS": [{"name": "nikshith", "password": "nikshith123"}],
    "STUDENTS": {},
    "TEACHERS": {},
    "BOOKS": {}
}

def initialize_data():
    # Sample books for all sems
    sample_books = [
        {"title": "Mathematics Basics", "author": "R. Sharma", "qty": 10},
        {"title": "Physics Essentials", "author": "K. Rao", "qty": 8},
        {"title": "Computer Fundamentals", "author": "A. Kumar", "qty": 12},
        {"title": "Engineering Chemistry", "author": "M. Iyer", "qty": 7},
    ]

    for dept in DEPTS:
        lms["STUDENTS"][dept] = {}
        lms["BOOKS"][dept] = {}
        for year in YEARS:
            lms["STUDENTS"][dept][year] = {}
            lms["BOOKS"][dept][year] = {}
            for sem in SEMS:
                lms["STUDENTS"][dept][year][sem] = []
                lms["BOOKS"][dept][year][sem] = [dict(book) for book in sample_books]
        lms["TEACHERS"][dept] = []

    print("Data initialized with default books for all branches, years, and semesters.")
    