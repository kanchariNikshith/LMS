from assets.data import lms

def admin_login():
    print("\nWelcome to ADMIN login\n")
    name = input("Enter your name: ").strip()
    password = input("Enter your password: ").strip()

    for admin in lms.get("ADMINS", []):
        if admin["name"] == name and admin["password"] == password:
            print("ADMIN login successful")
            return True
    print("Admin login failed")
    return False

def login(type_of_login):
    if type_of_login == "ADMIN":
        return admin_login()
    else:
        raise ValueError("Unknown login type: " + str(type_of_login))
