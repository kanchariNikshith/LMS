from assets.data import lms
from utils.display_utils import display_branch_details, display_year_details, display_sem_details

def handle_admin_choice(choice):
    if choice == 1:  # add student
        branch = display_branch_details()
        year = display_year_details()
        sem = display_sem_details()
        name = input("Enter student name: ").strip()
        pwd = input("Enter password: ").strip()
        lms["STUDENTS"][branch][year][sem].append({"name": name, "password": pwd, "books": []})
        print(f"✅ Student {name} added to {branch}-{year}-{sem}")
        input("\nPress Enter to continue...")

    elif choice == 2:  # add book
        branch = display_branch_details()
        year = display_year_details()
        sem = display_sem_details()
        title = input("Enter book title: ").strip()
        author = input("Enter author: ").strip()
        while True:
            qty_str = input("Enter quantity: ").strip()
            if qty_str.isdigit() and int(qty_str) >= 0:
                qty = int(qty_str)
                break
            print("❌ Invalid input — please enter a non-negative integer for quantity.")
        lms["BOOKS"][branch][year][sem].append({"title": title, "author": author, "qty": qty})
        print(f"✅ Book '{title}' added with {qty} copies to {branch}-{year}-{sem}")
        input("\nPress Enter to continue...")

    elif choice == 3:  # add teacher
        branch = display_branch_details()
        name = input("Enter teacher name: ").strip()
        pwd = input("Enter password: ").strip()
        subject = input("Enter subject: ").strip()
        lms["TEACHERS"][branch].append({"name": name, "password": pwd, "subject": subject})
        print(f"✅ Teacher {name} added to {branch} department for subject {subject}")
        input("\nPress Enter to continue...")

    elif choice == 4:  # add admin
        name = input("Enter new admin name: ").strip()
        pwd = input("Enter password: ").strip()
        lms["ADMINS"].append({"name": name, "password": pwd})
        print(f"✅ Admin {name} added")
        input("\nPress Enter to continue...")

    else:
        print("❌ Invalid choice")
