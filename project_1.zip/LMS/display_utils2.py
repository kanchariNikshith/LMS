"""
display_utils2.py
Neat printing/displaying logic for Books, Students, Teachers with for loops and formatting.
"""
from db_utils import read_db

def display_books():
    """Display all books neatly."""
    books = read_db("books")
    print("\n*** BORROWED BOOKS ***")
    # Aggregate borrowed books from students and teachers
    students = read_db("students")
    teachers = read_db("teachers")
    borrowed = []
    for s in students:
        for b in s.get("books", []):
            borrowed.append({"user": s["name"], "role": "Student", "title": b["title"], "due": b["due"]})
    for t in teachers:
        for b in t.get("books", []):
            borrowed.append({"user": t["name"], "role": "Teacher", "title": b["title"], "due": b["due"]})
    if not borrowed:
        print("No books are currently borrowed.")
    else:
        for i, b in enumerate(borrowed, 1):
            print(f"{i}. {b['role']}: {b['user']} | Title: {b['title']} | Due: {b['due']}")

def display_engineering_books(branch, year, sem):
    """Display engineering books by branch, year, and semester."""
    import json
    path = "assets/engineering_books.json"
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print("Error loading engineering books:", e)
        return
    found = False
    for entry in data:
        if (entry["branch"].lower() == branch.lower() or entry["branch"].lower() == "all") and \
           entry["year"].replace("-YEAR","").replace("YEAR","").replace("-year","").replace("year","").strip().lower() == year.strip().lower() and \
           entry["sem"].replace("-SEM","").replace("SEM","").replace("-sem","").replace("sem","").strip().lower() == sem.strip().lower():
            print(f"\n*** ENGINEERING BOOKS ({branch.upper()} {year} {sem}) ***")
            for i, book in enumerate(entry["books"], 1):
                    print(f"{i}. {book['title']} (Author: {book['author']})")
            found = True
        if not found:
            # Show all books grouped by year
            print(f"No exact match found for {branch.upper()} {year} {sem}. Showing all books grouped by year:")
            years = sorted(set(entry["year"] for entry in data if "year" in entry))
            for y in years:
                print(f"\n=== {y} ===")
                year_books = [entry for entry in data if entry.get("year") == y]
                for entry in year_books:
                    print(f"--- {entry.get('branch','')} {entry.get('sem','')} ---")
                    for i, book in enumerate(entry.get("books", []), 1):
                        print(f"{i}. {book['title']} (Author: {book['author']})")


def display_teachers():
    """Display all teachers neatly."""
    teachers = read_db("teachers")
    print("\n*** TEACHERS ***")
    for i, t in enumerate(teachers, 1):
        print(f"{i}. Name: {t['name']}, Subject: {t.get('subject','')}, Branch: {t.get('branch','')}")


def display_admins():
    """Display all admins neatly."""
    admins = read_db("admins")
    print("\n*** ADMINS ***")
    for i, a in enumerate(admins, 1):
        print(f"{i}. Name: {a['name']}")

def display_students():
    """Display all students neatly."""
    students = read_db("students")
    print("\n*** STUDENTS ***")
    for i, s in enumerate(students, 1):
        branch = s.get("branch", "")
        year = s.get("year", "")
        sem = s.get("sem", "")
        print(f"{i}. Name: {s['name']}, Branch: {branch}, Year: {year}, Sem: {sem}")

def display_books_for_student(student_name):
    """Display books for the logged-in student based on branch, year, and sem."""
    students = read_db("students")
    student = next((s for s in students if s["name"].lower() == student_name.lower()), None)
    if not student:
        print("❌ Student not found.")
        return
    branch = student.get("branch", "")
    year = student.get("year", "")
    sem = student.get("sem", "")
    books = read_db("books")
    filtered_books = [book for book in books if book.get("branch", "").lower() == branch.lower() and str(book.get("year", "")).lower() == str(year).lower() and str(book.get("sem", "")).lower() == str(sem).lower()]
    print(f"\n*** BOOKS for {student_name} ({branch}-{year}-{sem}) ***")
    if not filtered_books:
        print("No books found for your branch/year/sem.")
        return
    for i, book in enumerate(filtered_books, 1):
        print(f"{i}. Title: {book['title']}, Author: {book['author']}, Qty: {book['qty']}")

def display_engineering_books_for_student(student_name):
    """Display engineering books for the logged-in student based on branch, year, and sem."""
    import json
    students = read_db("students")
    student = next((s for s in students if s["name"].lower() == student_name.lower()), None)
    if not student:
        print("❌ Student not found.")
        return
    branch = student.get("branch", "").upper()
    year = student.get("year", "")
    sem = student.get("sem", "")
    # Convert year and sem to format like '3-YEAR', '6-SEM'
    year_str = f"{year}-YEAR"
    sem_num = str(int(year) * 2 if sem == "2" else int(year) * 2 - 1)  # 1st sem: odd, 2nd sem: even
    sem_str = f"{sem_num}-SEM"
    path = "assets/engineering_books.json"
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print("Error loading engineering books:", e)
        return
    found = False
    for entry in data:
        if entry.get("branch", "").upper() == branch and entry.get("year", "") == year_str and entry.get("sem", "") == sem_str:
            print(f"\n*** ENGINEERING BOOKS for {student_name} ({branch}-{year_str}-{sem_str}) ***")
            for i, book in enumerate(entry.get("books", []), 1):
                print(f"{i}. Title: {book['title']}, Author: {book['author']}")
            found = True
            break
    if not found:
        print("No engineering books found for your branch/year/sem.")
