def test_sample():
    assert 1 + 1 == 2
