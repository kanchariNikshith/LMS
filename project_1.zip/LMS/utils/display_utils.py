import os
from config import DEPTS, YEARS, SEMS

def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

def display_header(title):
    clear_screen()
    print("=" * 50)
    print(title.center(50))
    print("=" * 50)

def display_admin_options():
    while True:
        display_header("ADMIN MENU")
        print("1. Add Student")
        print("2. Add Book")
        print("3. Add Teacher")
        print("4. Add Admin")
        print("5. Logout")
        choice = input("\nEnter choice: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= 5:
            return int(choice)
        print("❌ Invalid input — please enter again.")

def display_student_options():
    while True:
        display_header("STUDENT MENU")
        print("1. View Books")
        print("2. Borrow Book")
        print("3. Return Book")
        print("4. Logout")
        choice = input("\nEnter choice: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= 4:
            return int(choice)
        print("❌ Invalid input — please enter again.")

def display_teacher_options():
    while True:
        display_header("TEACHER MENU")
        print("1. View Students")
        print("2. View Books in Branch")
        print("3. Logout")
        choice = input("\nEnter choice: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= 3:
            return int(choice)
        print("❌ Invalid input — please enter again.")

def display_login_options():
    while True:
        display_header("LOGIN")
        print("1. Admin")
        print("2. Student")
        print("3. Teacher")
        print("4. View Full Data")
        print("5. Exit")
        choice = input("\nEnter choice: ").strip()
        if choice in {"1", "2", "3", "4", "5"}:
            return choice
        print("❌ Invalid input — please enter again.")

def display_branch_details():
    while True:
        display_header("BRANCH SELECTION")
        for i, dept in enumerate(DEPTS, 1):
            print(f"{i}. {dept}")
        choice = input("\nSelect branch (number): ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(DEPTS):
            return DEPTS[int(choice) - 1]
        print("❌ Invalid input — please enter again.")

def display_year_details():
    while True:
        display_header("YEAR SELECTION")
        for i, year in enumerate(YEARS, 1):
            print(f"{i}. {year}")
        choice = input("\nSelect year (number): ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(YEARS):
            return YEARS[int(choice) - 1]
        print("❌ Invalid input — please enter again.")

def display_sem_details():
    while True:
        display_header("SEMESTER SELECTION")
        for i, sem in enumerate(SEMS, 1):
            print(f"{i}. {sem}")
        choice = input("\nSelect semester (number): ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(SEMS):
            return SEMS[int(choice) - 1]
        print("❌ Invalid input — please enter again.")
