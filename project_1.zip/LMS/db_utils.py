"""
db_utils.py
Utility functions for reading/writing JSON database files for LMS.
"""
import json
import os
from typing import Any, Dict, List

DB_PATHS = {
    "students": "students.json",
    "teachers": "teachers.json",
    "admins": "admins.json",
    "books": "books.json"
}

def read_db(db_name: str) -> List[Dict[str, Any]]:
    """Read data from a JSON file."""
    path = DB_PATHS[db_name]
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def write_db(db_name: str, data: List[Dict[str, Any]]):
    """Write data to a JSON file."""
    path = DB_PATHS[db_name]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def update_db(db_name: str, data: List[Dict[str, Any]]):
    """Update (overwrite) the JSON file."""
    write_db(db_name, data)

def delete_db_record(db_name: str, key: str, value: Any):
    """Delete a record from the JSON file by key/value."""
    data = read_db(db_name)
    new_data = [rec for rec in data if rec.get(key) != value]
    write_db(db_name, new_data)

def find_db_record(db_name: str, key: str, value: Any) -> Dict[str, Any]:
    """Find a record in the JSON file by key/value."""
    data = read_db(db_name)
    for rec in data:
        if rec.get(key) == value:
            return rec
    return None
