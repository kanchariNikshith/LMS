# Library Management System (LMS)

## Overview
This project is a Library Management System (LMS) built in Python. It allows administrators, students, and teachers to manage library resources, including borrowing and returning books, viewing users, and maintaining records. The system uses JSON files for data storage and provides a simple command-line interface for interaction.

## Features
- **Admin:**
	- Add students, teachers, books, and other admins
	- Update and delete records
	- View all data in the system
- **Student:**
	- View available books
	- Borrow and return books
	- View borrowed books
- **Teacher:**
	- View students
	- Borrow and return books
	- View borrowed books

## Data Storage
All data is stored in JSON files:
- `books.json`: List of all books in the library
- `students.json`: Student records and borrowed books
- `teachers.json`: Teacher records and borrowed books
- `admins.json`: Admin records

## How It Works
1. **Login:** Users log in as admin, student, or teacher.
2. **Menu Navigation:** Each role has a dedicated menu with relevant options.
3. **Book Management:** Students and teachers can borrow/return books. Admins can add/update/delete books and users.
4. **Borrowed Books Tracking:** The system tracks which user has borrowed which book and the due date.
5. **View Full Data:** Admins can view all users and borrowed books data.

## Project Structure
- `main.py`: Main entry point, handles user flow and menus
- `menu.py`: Menu display functions
- `display_utils2.py`: Functions for displaying users and books
- `book_management.py`: Logic for borrowing and returning books
- `crud.py`: Create, read, update, delete operations
- `db_utils.py`: Database utility functions for reading/writing JSON
- `assets/`: Additional data files
- `commons/`, `utils/`: Helper modules
- `tests/`: Test scripts

## How to Run
1. Install Python 3.12 or higher
2. Run `main.py`:
	 ```
	 python main.py
	 ```
3. Follow the prompts in the command-line interface

## Notes
- All book quantities and user data are managed via JSON files
- The system is designed for educational/demo purposes and can be extended for real-world use

## Author
Created by [Your Name]
# Library Management System
- Library management system is a software developed for Librarians to manage Books, Students,Departments, and Teacher, etc.
