"""
lms_login.py
Login system for Admin, Student, Teacher with multiprocessing and efficient search.
"""
import multiprocessing
from db_utils import read_db

def admin_login(name: str, password: str) -> bool:
    """Admin login using filter()."""
    admins = read_db("admins")
    result = list(filter(lambda a: a["name"] == name and a["password"] == password, admins))
    return bool(result)

def student_login(name: str, password: str) -> bool:
    """Student login using for loop."""
    students = read_db("students")
    for s in students:
        if s["name"] == name and s["password"] == password:
            return True
    return False

def teacher_login(name: str, password: str) -> bool:
    """Teacher login using for loop."""
    teachers = read_db("teachers")
    for t in teachers:
        if t["name"] == name and t["password"] == password:
            return True
    return False

def parallel_login(role: str, name: str, password: str) -> bool:
    """Efficient login using multiprocessing for all roles."""
    with multiprocessing.Pool(processes=2) as pool:
        if role == "admin":
            res = pool.apply_async(admin_login, (name, password))
        elif role == "student":
            res = pool.apply_async(student_login, (name, password))
        elif role == "teacher":
            res = pool.apply_async(teacher_login, (name, password))
        else:
            return False
        return res.get()
