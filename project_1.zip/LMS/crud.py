"""
crud.py
CRUD operations for Students, Teachers, Admins, Books. Only Admin can Create/Delete.
"""
from db_utils import read_db, write_db, update_db, delete_db_record, find_db_record
from typing import Dict, Any, List

def create_record(db_name: str, record: Dict[str, Any], is_admin: bool) -> bool:
    """Create a record (only if admin)."""
    if not is_admin:
        print("❌ Only admin can create records.")
        return False
    data = read_db(db_name)
    data.append(record)
    write_db(db_name, data)
    print(f"✅ Record added to {db_name}.")
    return True

def read_records(db_name: str) -> List[Dict[str, Any]]:
    """Read all records."""
    return read_db(db_name)

def update_record(db_name: str, key: str, value: Any, updates: Dict[str, Any], is_admin: bool) -> bool:
    """Update a record (admin only)."""
    if not is_admin:
        print("❌ Only admin can update records.")
        return False
    data = read_db(db_name)
    updated = False
    for rec in data:
        if rec.get(key) == value:
            rec.update(updates)
            updated = True
    if updated:
        write_db(db_name, data)
        print(f"✅ Record updated in {db_name}.")
    else:
        print("❌ Record not found.")
    return updated

def delete_record(db_name: str, key: str, value: Any, is_admin: bool) -> bool:
    """Delete a record (admin only)."""
    if not is_admin:
        print("❌ Only admin can delete records.")
        return False
    delete_db_record(db_name, key, value)
    print(f"✅ Record deleted from {db_name}.")
    return True
