"""
main.py
Main entry point for LMS. Handles menu and user flow.
"""
from menu import print_main_menu, print_admin_menu, print_student_menu, print_teacher_menu
from display_utils2 import display_books, display_students, display_teachers, display_admins
from lms_login import parallel_login
from crud import create_record, read_records, update_record, delete_record
from book_management import take_book, return_book

def main():
    def display_specific_books(branch, year, sem):
        import json
        try:
            with open("books.json", "r", encoding="utf-8") as f:
                books_data = json.load(f)
            branch_books = books_data.get(branch, {})
            year_books = branch_books.get(year, {})
            sem_books = year_books.get(sem, [])
            print(f"\n*** BOOKS for {branch} {year} {sem} ***")
            if not sem_books:
                print("No books found for this selection.")
            else:
                for i, book in enumerate(sem_books, 1):
                    print(f"{i}. {book['title']} (Author: {book['author']}, Qty: {book['qty']})")
        except Exception as e:
            print("Error reading books.json:", e)
    """Main menu loop for LMS."""
    while True:
        print_main_menu()
        choice = input("Enter choice: ").strip()
        if choice == "1":
            print_admin_menu()
            name = input("Admin Name: ").strip()
            pwd = input("Password: ").strip()
            is_admin = parallel_login("admin", name, pwd)
            if is_admin:
                print("✅ Admin login successful.")
                while True:
                    print_admin_menu()
                    admin_choice = input("Enter admin menu choice: ").strip()
                    if admin_choice == "1":
                        # Add Student
                        print("Enter student details:")
                        s_name = input("Name: ").strip()
                        s_branch = input("Branch: ").strip()
                        s_year = input("Year: ").strip()
                        s_sem = input("Semester: ").strip()
                        s_pwd = input("Password: ").strip()
                        student = {"name": s_name, "branch": s_branch, "year": s_year, "sem": s_sem, "password": s_pwd}
                        create_record("students", student, is_admin)
                    elif admin_choice == "2":
                        # Add Book
                        print("Enter book details:")
                        b_title = input("Title: ").strip()
                        b_author = input("Author: ").strip()
                        b_qty = input("Quantity: ").strip()
                        try:
                            b_qty = int(b_qty)
                        except ValueError:
                            print("❌ Quantity must be an integer.")
                            continue
                        book = {"title": b_title, "author": b_author, "qty": b_qty}
                        create_record("books", book, is_admin)
                    elif admin_choice == "3":
                        # Add Teacher
                        print("Enter teacher details:")
                        t_name = input("Name: ").strip()
                        t_branch = input("Branch: ").strip()
                        t_subject = input("Subject: ").strip()
                        t_pwd = input("Password: ").strip()
                        teacher = {"name": t_name, "branch": t_branch, "subject": t_subject, "password": t_pwd}
                        create_record("teachers", teacher, is_admin)
                    elif admin_choice == "4":
                        # Add Admin
                        print("Enter admin details:")
                        a_name = input("Name: ").strip()
                        a_pwd = input("Password: ").strip()
                        admin = {"name": a_name, "password": a_pwd}
                        create_record("admins", admin, is_admin)
                    elif admin_choice == "5":
                        # Update Record
                        print("Update which database? (students/teachers/admins/books)")
                        db_name = input("DB: ").strip()
                        key = input("Key to match (e.g. name): ").strip()
                        value = input("Value to match: ").strip()
                        print("Enter fields to update (key=value, comma separated):")
                        updates_raw = input("Updates: ").strip()
                        updates = {}
                    elif admin_choice == "6":
                        # Delete Record
                        print("Delete from which database? (students/teachers/admins/books)")
                        db_name = input("DB: ").strip()
                        key = input("Key to match (e.g. name): ").strip()
                        value = input("Value to match: ").strip()
                        delete_record(db_name, key, value, is_admin)
                    elif admin_choice == "7":
                        print("Logging out...")
                        break
                    else:
                        print("Invalid choice.")
        elif choice == "2":
            name = input("Student Name: ").strip()
            pwd = input("Password: ").strip()
            is_student = parallel_login("student", name, pwd)
            if is_student:
                print("✅ Student login successful.")
                import datetime
                from db_utils import read_db, write_db
                while True:
                    print_student_menu()
                    student_choice = input("Enter student menu choice: ").strip()
                    if student_choice == "1":
                        # Select branch/year/sem by options
                        from config import DEPTS, YEARS, SEMS
                        import json
                        print("Select Branch:")
                        for i, dept in enumerate(DEPTS, 1):
                            print(f"{i}. {dept}")
                        branch_idx = input("Enter branch number: ").strip()
                        if not branch_idx.isdigit() or not (1 <= int(branch_idx) <= len(DEPTS)):
                            print("Invalid branch selection.")
                            continue
                        branch = DEPTS[int(branch_idx)-1]
                        print("Select Year:")
                        for i, year in enumerate(YEARS, 1):
                            print(f"{i}. {year}")
                        year_idx = input("Enter year number: ").strip()
                        if not year_idx.isdigit() or not (1 <= int(year_idx) <= len(YEARS)):
                            print("Invalid year selection.")
                            continue
                        year = YEARS[int(year_idx)-1]
                        print("Select Semester:")
                        for i, sem in enumerate(SEMS, 1):
                            print(f"{i}. {sem}")
                        sem_idx = input("Enter semester number: ").strip()
                        if not sem_idx.isdigit() or not (1 <= int(sem_idx) <= len(SEMS)):
                            print("Invalid semester selection.")
                            continue
                        sem = SEMS[int(sem_idx)-1]
                        display_specific_books(branch, year, sem)
                    elif student_choice == "2":
                        # Take Book
                        books = read_db("books")
                        print("Enter book title to borrow:")
                        book_title = input("Book Title: ").strip()
                        found = False
                        for book in books:
                            if book["title"].lower() == book_title.lower() and book["qty"] > 0:
                                take_book("student", name, book_title)
                                # Add to student's borrowed list
                                students = read_db("students")
                                for s in students:
                                    if s["name"] == name:
                                        due = str(datetime.date.today() + datetime.timedelta(days=14))
                                        if "books" not in s:
                                            s["books"] = []
                                        s["books"].append({"title": book_title, "due": due})
                                        write_db("students", students)
                                        print(f"Book '{book_title}' borrowed. Due: {due}")
                                        found = True
                                        break
                                break
                        if not found:
                            print("❌ Book not available or out of stock.")
                    elif student_choice == "3":
                        # Return Book
                        students = read_db("students")
                        for s in students:
                            if s["name"] == name:
                                if not s.get("books"):
                                    print("❌ No borrowed books.")
                                    break
                                print("Your borrowed books:")
                                for i, b in enumerate(s["books"], 1):
                                    print(f"{i}. {b['title']} (Due: {b['due']})")
                                idx = input("Enter number to return: ").strip()
                                try:
                                    idx = int(idx) - 1
                                    ret_book = s["books"][idx]
                                    return_book("student", name, ret_book["title"])
                                    # Overdue check
                                    due_date = datetime.datetime.strptime(ret_book["due"], "%Y-%m-%d")
                                    if datetime.date.today() > due_date.date():
                                        print("⚠️ Book is overdue!")
                                    s["books"].pop(idx)
                                    write_db("students", students)
                                    print(f"Returned '{ret_book['title']}'")
                                except (ValueError, IndexError):
                                    print("❌ Invalid selection.")
                                break
                    elif student_choice == "4":
                        print("Logging out...")
                        break
                    elif student_choice == "5":
                        # Display borrowed books
                        students = read_db("students")
                        for s in students:
                            if s["name"] == name:
                                print("Your borrowed books:")
                                if not s.get("books"):
                                    print("None.")
                                else:
                                    for b in s["books"]:
                                        print(f"- {b['title']} (Due: {b['due']})")
                                break
                    else:
                        print("Invalid choice.")
            else:
                print("❌ Student login failed.")
        elif choice == "3":
            print_teacher_menu()
            name = input("Teacher Name: ").strip()
            pwd = input("Password: ").strip()
            is_teacher = parallel_login("teacher", name, pwd)
            if is_teacher:
                print("✅ Teacher login successful.")
                import datetime
                from db_utils import read_db, write_db
                while True:
                    print_teacher_menu()
                    teacher_choice = input("Enter teacher menu choice: ").strip()
                    if teacher_choice == "1":
                        display_students()
                    elif teacher_choice == "2":
                        # Take Book
                        books = read_db("books")
                        print("Enter book title to borrow:")
                        book_title = input("Book Title: ").strip()
                        found = False
                        for book in books:
                            if book["title"].lower() == book_title.lower() and book["qty"] > 0:
                                take_book("teacher", name, book_title)
                                teachers = read_db("teachers")
                                for t in teachers:
                                    if t["name"] == name:
                                        due = str(datetime.date.today() + datetime.timedelta(days=14))
                                        if "books" not in t:
                                            t["books"] = []
                                        t["books"].append({"title": book_title, "due": due})
                                        write_db("teachers", teachers)
                                        print(f"Book '{book_title}' borrowed. Due: {due}")
                                        found = True
                                        break
                                break
                        if not found:
                            print("❌ Book not available or out of stock.")
                    elif teacher_choice == "3":
                        # Return Book
                        teachers = read_db("teachers")
                        for t in teachers:
                            if t["name"] == name:
                                if not t.get("books"):
                                    print("❌ No borrowed books.")
                                    break
                                print("Your borrowed books:")
                                for i, b in enumerate(t["books"], 1):
                                    print(f"{i}. {b['title']} (Due: {b['due']})")
                                idx = input("Enter number to return: ").strip()
                                try:
                                    idx = int(idx) - 1
                                    ret_book = t["books"][idx]
                                    return_book("teacher", name, ret_book["title"])
                                    due_date = datetime.datetime.strptime(ret_book["due"], "%Y-%m-%d")
                                    if datetime.date.today() > due_date.date():
                                        print("⚠️ Book is overdue!")
                                    t["books"].pop(idx)
                                    write_db("teachers", teachers)
                                    print(f"Returned '{ret_book['title']}'")
                                except (ValueError, IndexError):
                                    print("❌ Invalid selection.")
                                break
                    elif teacher_choice == "4":
                        print("Logging out...")
                        break
                    else:
                        print("Invalid choice.")
            else:
                print("❌ Teacher login failed.")
        elif choice == "4":
            print("\n=== FULL LMS DATA ===")
            display_admins()
            display_teachers()
            display_students()
            display_books()
        elif choice == "5":
            print("\nSystem shutting down... Goodbye")
            break
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()