DEPTS = ["CSE", "CIVIL", "IT", "ECE", "EEE", "MECH"]
YEARS = [f"{i}-YEAR" for i in range(1, 5)]
SEMS = [f"{i}-SEM" for i in range(1, 3)]
