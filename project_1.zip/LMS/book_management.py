"""
book_management.py
Logic for Students & Teachers to take/return books.
"""
from db_utils import read_db, write_db
from typing import Dict, Any
import datetime

def take_book(user_type: str, user_name: str, book_title: str) -> bool:
    """Allow student/teacher to take a book."""
    books = read_db("books")
    for book in books:
        if book["title"] == book_title and book["qty"] > 0:
            book["qty"] -= 1
            write_db("books", books)
            # Add to user's borrowed list (not implemented: would need user record update)
            print(f"📚 {user_type.title()} {user_name} took '{book_title}' (Due: {datetime.date.today() + datetime.timedelta(days=14)})")
            return True
    print("❌ Book not available or out of stock.")
    return False

def return_book(user_type: str, user_name: str, book_title: str) -> bool:
    """Allow student/teacher to return a book."""
    books = read_db("books")
    for book in books:
        if book["title"] == book_title:
            book["qty"] += 1
            write_db("books", books)
            # Remove from user's borrowed list (not implemented: would need user record update)
            print(f"✅ {user_type.title()} {user_name} returned '{book_title}'")
            return True
    print("❌ Book not found in database.")
    return False
