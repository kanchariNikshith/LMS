from assets.data import lms
import datetime
from utils.display_utils import display_branch_details, display_year_details, display_sem_details

current_student = None  # track logged in student

from assets.data import lms
import datetime
from utils.display_utils import display_branch_details, display_year_details, display_sem_details

current_student = None  # track logged in student

def login_student():
    global current_student
    print("\n--- STUDENT LOGIN ---")

    branch = display_branch_details()
    year = display_year_details()
    sem = display_sem_details()

    name = input("Enter student name: ").strip()
    pwd = input("Enter password: ").strip()

    students_list = lms["STUDENTS"].get(branch, {}).get(year, {}).get(sem, [])

    for student in students_list:
        if student["name"] == name and student["password"] == pwd:
            print(f"✅ Login successful. Welcome {name} ({branch}-{year}-{sem})")
            current_student = {"branch": branch, "year": year, "sem": sem, "data": student}
            return True

    print("❌ Login failed. Try again.")
    return False


def view_books():
    """Show books available in student's OWN branch/year/sem"""
    if current_student is None:
        print("❌ No student logged in.")
        return

    b = current_student["branch"]
    y = current_student["year"]
    s = current_student["sem"]

    books = lms["BOOKS"].get(b, {}).get(y, {}).get(s, [])
    if not books:
        print(f"❌ No books available in {b}-{y}-{s}.")
        return

    print(f"\n📚 Available books in {b}-{y}-{s}:")
    for i, book in enumerate(books, 1):
        print(f"{i}. {book['title']} by {book['author']} (Qty: {book['qty']})")
    found = False
    if not found:
        print(f"❌ No books available in {y}-{s}.")


def take_book():
    """Allow student to take books only from their own branch/year/sem"""
    if current_student is None:
        print("❌ No student logged in.")
        return

    b = current_student["branch"]
    y = current_student["year"]
    s = current_student["sem"]

    books = lms["BOOKS"].get(b, {}).get(y, {}).get(s, [])
    if not books:
        print("❌ No books available.")
        return

    print(f"\nAvailable books in {b}-{y}-{s}:")
    for i, book in enumerate(books, 1):
        print(f"{i}. {book['title']} by {book['author']} (Qty: {book['qty']})")

    try:
        choice = int(input("Select book number to take: "))
        if 1 <= choice <= len(books):
            book = books[choice - 1]
            if book["qty"] > 0:
                book["qty"] -= 1
                due = datetime.date.today() + datetime.timedelta(days=14)
                current_student["data"]["books"].append({
                    "title": book["title"],
                    "branch": b,
                    "year": y,
                    "sem": s,
                    "due": str(due),
                })
                print(f"📚 Taken {book['title']} (Due: {due})")
            else:
                print("❌ No copies left.")
        else:
            print("❌ Invalid choice.")
    except ValueError:
        print("❌ Enter a valid number.")


def return_book():
    """Return a borrowed book"""
    if current_student is None:
        print("❌ No student logged in.")
        return

    data = current_student["data"]
    if not data["books"]:
        print("❌ You have not borrowed any books.")
        return

    print("\nYour borrowed books:")
    for i, b in enumerate(data["books"], 1):
        print(f"{i}. {b['title']} ({b['branch']}-{b['year']}-{b['sem']}) (Due: {b['due']})")

    try:
        choice = int(input("Select book number to return: "))
        if 1 <= choice <= len(data["books"]):
            ret = data["books"].pop(choice - 1)
            # Return book to LMS
            for book in lms["BOOKS"][ret["branch"]][ret["year"]][ret["sem"]]:
                if book["title"] == ret["title"]:
                    book["qty"] += 1
                    break
            print(f"✅ Returned {ret['title']}")
        else:
            print("❌ Invalid choice.")
    except ValueError:
        print("❌ Enter a valid number.")


def handle_student_choice(choice):
    if choice == 1:
        view_books()
    elif choice == 2:
        take_book()
    elif choice == 3:
        return_book()
    else:
        print("❌ Invalid choice")
