from assets.data import lms
from utils.display_utils import display_branch_details, display_year_details, display_sem_details

current_teacher = None

def login_teacher():
    global current_teacher
    print("\n-- TEACHER LOGIN --")
    branch = display_branch_details()  # validated selection
    name = input("Enter teacher name: ").strip()
    pwd = input("Enter password: ").strip()
    for t in lms["TEACHERS"].get(branch, []):
        if t["name"] == name and t["password"] == pwd:
            print(f"✅ Welcome {name} ({t['subject']})")
            current_teacher = {"branch": branch, "data": t}
            return True
    print("❌ Teacher login failed")
    return False


def handle_teacher_choice(choice):
    if choice == 1:
        # View students in a class
        branch = current_teacher["branch"]  # teacher's branch
        print(f"\n-- STUDENT INFO FOR {branch} --")
        year = display_year_details()       # validated selection
        sem = display_sem_details()         # validated selection

        students = lms["STUDENTS"][branch][year][sem]
        if not students:
            print(f"No students found in {branch}-{year}-{sem}.")
            return

        print(f"\nStudents in {branch}-{year}-{sem}:")
        for i, student in enumerate(students, 1):
            print(f"{i}. Name: {student['name']}, Password: {student['password']}")
            if student["books"]:
                print("   Borrowed books:")
                for b in student["books"]:
                    print(f"     - {b['title']} (Due: {b['due']})")
            else:
                print("   No borrowed books.")

    elif choice == 2:
        # View books in branch
        branch = current_teacher["branch"]
        print(f"\n-- BOOKS IN {branch} --")
        for year, sems in lms["BOOKS"][branch].items():
            for sem, books in sems.items():
                print(f"{year}-{sem}:")
                if books:
                    for b in books:
                        print(f" - {b['title']} (Qty: {b['qty']})")
                else:
                    print("   No books.")
    elif choice == 3:
        print("Logging out...")
    else:
        print("❌ Invalid choice")
