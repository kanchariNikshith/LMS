from assets.data import lms
from utils.display_utils import display_branch_details, display_year_details, display_sem_details

def add_book():
    branch = display_branch_details()
    year = display_year_details()
    sem = display_sem_details()
    title = input("Enter book title: ").strip()
    author = input("Enter author: ").strip()
    # validate quantity
    while True:
        qty_str = input("Enter quantity: ").strip()
        if qty_str.isdigit() and int(qty_str) >= 0:
            qty = int(qty_str)
            break
        print("❌ Invalid input — please enter a non-negative integer for quantity.")
    lms["BOOKS"][branch][year][sem].append({"title": title, "author": author, "qty": qty})
    print(f"✅ Book '{title}' added with {qty} copies to {branch}-{year}-{sem}")
    