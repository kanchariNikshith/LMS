"""
menu.py
Menu system with clear formatting for all roles and actions.
"""
def print_main_menu():
    print("\n=== LMS MAIN MENU ===")
    print("1. Admin Login")
    print("2. Student Login")
    print("3. Teacher Login")
    print("4. View Full Data")
    print("5. Exit")

def print_admin_menu():
    print("\n*** ADMIN MENU ***")
    print("1. Add Student")
    print("2. Add Book")
    print("3. Add Teacher")
    print("4. Add Admin")
    print("5. Update Record")
    print("6. Delete Record")
    print("7. Logout")

def print_student_menu():
    print("\n*** STUDENT MENU ***")
    print("1. View Books")
    print("2. Take Book")
    print("3. Return Book")
    print("4. Logout")

def print_teacher_menu():
    print("\n*** TEACHER MENU ***")
    print("1. View Students")
    print("2. Take Book")
    print("3. Return Book")
    print("4. Logout")
