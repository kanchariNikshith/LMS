from assets.data import lms
from utils.display_utils import display_header

def display_full_data():
    display_header("FULL LMS DATA")

    # Admins
    print("=== ADMINS ===")
    if "ADMINS" in lms and lms["ADMINS"]:
        index = 1
        for admin in lms["ADMINS"]:
            print(str(index) + ". Name: " + admin["name"] + ", Password: " + admin["password"])
            index += 1
    else:
        print("No admins found.")
    print("-" * 50)

    # Teachers
    print("=== TEACHERS ===")
    if "TEACHERS" in lms:
        for dept in lms["TEACHERS"]:
            print("\nDepartment: " + dept)
            teachers = lms["TEACHERS"][dept]
            if teachers:
                index = 1
                for t in teachers:
                    print("  " + str(index) + ". Name: " + t["name"] + ", Subject: " + t["subject"] + ", Password: " + t["password"])
                    index += 1
            else:
                print("  No teachers found.")
    else:
        print("No teachers found.")
    print("-" * 50)

    # Students
    print("=== STUDENTS ===")
    if "STUDENTS" in lms:
        for dept in lms["STUDENTS"]:
            print("\nDepartment: " + dept)
            years = lms["STUDENTS"][dept]
            for year in years:
                sems = years[year]
                for sem in sems:
                    students = sems[sem]
                    print("  " + year + " - " + sem + ":")
                    if students:
                        index = 1
                        for s in students:
                            book_list = ""
                            if s["books"]:
                                for b in s["books"]:
                                    book_list += b["title"] + ", "
                                book_list = book_list[:-2]  # remove last comma
                            else:
                                book_list = "No borrowed books"
                            print("    " + str(index) + ". Name: " + s["name"] + ", Password: " + s["password"] + ", Books: " + book_list)
                            index += 1
                    else:
                        print("    No students found.")
    else:
        print("No students found.")
    print("-" * 50)

    # Books
    print("=== BOOKS ===")
    if "BOOKS" in lms:
        for dept in lms["BOOKS"]:
            print("\nDepartment: " + dept)
            years = lms["BOOKS"][dept]
            for year in years:
                sems = years[year]
                for sem in sems:
                    books = sems[sem]
                    print("  " + year + " - " + sem + ":")
                    if books:
                        index = 1
                        for b in books:
                            print("    " + str(index) + ". " + b["title"] + " by " + b["author"] + " (Qty: " + str(b["qty"]) + ")")
                            index += 1
                    else:
                        print("    No books found.")
    else:
        print("No books found.")

    input("\nPress Enter to return to main menu...")
